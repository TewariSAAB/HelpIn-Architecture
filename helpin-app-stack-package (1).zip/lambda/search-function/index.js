exports.handler = async (event) => {
  const origin = process.env.CORS_ALLOWED_ORIGIN || '*';
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': origin
    },
    body: JSON.stringify({
      message: 'HelpIn SearchFunction is deployed',
      path: event.path,
      query: event.queryStringParameters || {}
    })
  };
};
